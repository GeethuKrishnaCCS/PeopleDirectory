/* tslint:disable */
require("./Directory.module.css");
const styles = {
  directory: 'directory_626f0ea4',
  dropDownSortBy: 'dropDownSortBy_626f0ea4',
  searchBox: 'searchBox_626f0ea4',
  noUsers: 'noUsers_626f0ea4',
  pivotItem: 'pivotItem_626f0ea4',
  container: 'container_626f0ea4',
  row: 'row_626f0ea4',
  column: 'column_626f0ea4',
  'ms-Grid': 'ms-Grid_626f0ea4',
  title: 'title_626f0ea4',
  subTitle: 'subTitle_626f0ea4',
  description: 'description_626f0ea4',
  button: 'button_626f0ea4',
  label: 'label_626f0ea4',
  alphabets: 'alphabets_626f0ea4',
  searchTextBox: 'searchTextBox_626f0ea4',
  dropdown: 'dropdown_626f0ea4',
  filterDiv: 'filterDiv_626f0ea4',
  sortDiv: 'sortDiv_626f0ea4'
};

export default styles;
/* tslint:enable */