/* tslint:disable */
require("./Paging.module.css");
const styles = {
  paginationContainer: 'paginationContainer_6b71167c',
  searchWp__paginationContainer__pagination: 'searchWp__paginationContainer__pagination_6b71167c',
  active: 'active_6b71167c',
  circularIcon: 'circularIcon_6b71167c',
  actionButton: 'actionButton_6b71167c'
};

export default styles;
/* tslint:enable */